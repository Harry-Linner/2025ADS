#include <stdio.h>
#include "AVLTree.h"
#include "BST.h"

int main()
{
    //调用方法示例
    AVLNode* AVLroot = createAVL(NULL);

    BSTNode* BSTroot = createBST(NULL);
    
    return 0;
}